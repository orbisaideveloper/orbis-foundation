TASK-019 — Secure Capability Approval Flow

This package is Termux-only. It does not commit or push to GitHub.

IMPORTANT: This package was source-audited against the ORBIS main branch before use.
Do NOT run the installer if the local repository has unrelated uncommitted changes
that must be preserved without a backup.

Apply:
  cd ~/orbis-foundation
  node TASK-019-secure-approval-flow/apply-task-019.mjs

Then validate:
  npm run type-check
  npm test
  npm run build
  npm run lint
  npm run check:circular

Then inspect:
  git diff --check
  git status --short
  git diff

Rollback before commit:
  cd ~/orbis-foundation
  node TASK-019-secure-approval-flow/rollback-task-019.mjs

No GitHub write, commit, or push is performed by the installer.
