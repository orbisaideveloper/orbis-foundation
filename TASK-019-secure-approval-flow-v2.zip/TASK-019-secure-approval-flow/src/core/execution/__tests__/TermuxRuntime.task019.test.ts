import { afterEach, describe, expect, it, vi } from "vitest";
import { TermuxRuntime } from "../runtimes/TermuxRuntime";

afterEach(() => vi.unstubAllGlobals());

describe("TASK-019 TermuxRuntime input forwarding", () => {
  it("sends the allow-list input to bridge.cjs", async () => {
    const calls: Array<{ url: string; init?: RequestInit }> = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string, init?: RequestInit) => {
      calls.push({ url, init });
      if (url.endsWith("/api/termux/handshake")) {
        return new Response(JSON.stringify({
          identity: { valid: true },
          capabilities: ["termux.system.info", "termux.file.read"],
          status: "CAPABILITIES_VERIFIED",
        }), { status: 200, headers: { "content-type": "application/json" } });
      }
      return new Response(JSON.stringify({
        success: true,
        data: { path: "package.json", content: "{}", sizeBytes: 2 },
      }), { status: 200, headers: { "content-type": "application/json" } });
    }));

    const runtime = new TermuxRuntime();
    await runtime.performHandshake();
    const result = await runtime.execute({
      requestId: "brain-req-task019",
      capability: "termux.file.read",
      input: { path: "package.json" },
      requestedRuntime: "TermuxRuntime",
    } as any);

    expect(result.success).toBe(true);
    const executionCall = calls.find((c) => c.url.endsWith("/api/termux/capability"));
    expect(executionCall).toBeDefined();
    expect(JSON.parse(String(executionCall?.init?.body))).toEqual({
      capability: "termux.file.read",
      input: { path: "package.json" },
    });
  });
});
