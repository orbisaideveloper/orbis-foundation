#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const files = [
  'src/core/execution/authorization/SecureExecutionAuthorizationGate.ts',
  'src/core/execution/runtimes/TermuxRuntimeService.ts',
  'src/core/execution/runtimes/TermuxRuntime.ts',
  'src/core/execution/interfaces/IExecutionResult.ts',
  'src/core/brain/ControlledCapabilityExecution.ts',
  'src/core/brain/BrainCapabilityOrchestrator.ts',
  'src/core/brain/BrainRequestGateway.ts',
  'orbis-server/ai/AIChatService.cjs',
  'orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs',
];

for (const file of files) {
  const full = path.join(root, file);
  const dir = path.dirname(full);
  if (!fs.existsSync(dir)) continue;
  const base = path.basename(file);
  const backups = fs.readdirSync(dir)
    .filter((name) => name.startsWith(`${base}.task019-backup-`))
    .sort()
    .reverse();
  if (backups.length) {
    fs.copyFileSync(path.join(dir, backups[0]), full);
    console.log(`RESTORE ${file}`);
  } else {
    console.log(`SKIP ${file}: no TASK-019 backup found`);
  }
}

const createdFiles = [
  'src/core/execution/authorization/PendingApprovalStore.ts',
  'src/core/execution/__tests__/PendingApprovalStore.task019.test.ts',
  'src/core/execution/__tests__/SecureExecutionAuthorizationGate.task019.test.ts',
  'src/core/execution/__tests__/TermuxRuntime.task019.test.ts',
  'orbis-server/__tests__/ChatCapabilityIntentMatcher.task019.test.mjs',
];

for (const file of createdFiles) {
  const full = path.join(root, file);
  if (fs.existsSync(full)) {
    fs.unlinkSync(full);
    console.log(`DELETE ${file}`);
  }
}

console.log('TASK-019 rollback complete. Git status should be checked before any commit.');
