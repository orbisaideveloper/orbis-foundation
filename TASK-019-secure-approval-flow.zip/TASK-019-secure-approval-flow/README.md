# ORBIS TASK-019 — Secure Capability Approval Flow

This ZIP is a Termux-ready implementation package. It does NOT push to GitHub.

Run from the ORBIS repository root:
`node TASK-019-secure-approval-flow/apply-task-019.mjs`

The installer is fail-closed: it checks the audited TASK-018 baseline before changing files, creates timestamped backups, and stops on mismatch.

After applying:
`npm run type-check && npm test && npm run build`

Inspect:
`git diff --check && git diff`

Rollback:
`node TASK-019-secure-approval-flow/rollback-task-019.mjs`
