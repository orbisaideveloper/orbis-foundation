#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const pkg = 'TASK-019-secure-approval-flow';
const now = new Date().toISOString().replace(/[:.]/g, '-');
const files = [
  'src/core/execution/authorization/SecureExecutionAuthorizationGate.ts',
  'src/core/execution/runtimes/TermuxRuntimeService.ts',
  'src/core/execution/interfaces/IExecutionResult.ts',
  'src/core/brain/ControlledCapabilityExecution.ts',
  'src/core/brain/BrainCapabilityOrchestrator.ts',
  'src/core/brain/BrainRequestGateway.ts',
  'orbis-server/ai/AIChatService.cjs',
  'orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs',
];
const A = (p) => path.join(ROOT,p);
const read = (p) => fs.readFileSync(A(p),'utf8');
const write = (p,s) => fs.writeFileSync(A(p),s,'utf8');
const backup = (p) => fs.copyFileSync(A(p), `${A(p)}.task019-backup-${now}`);
function replaceOnce(p, oldText, newText) {
  const s=read(p); const n=s.split(oldText).length-1;
  if(n!==1) throw new Error(`TASK-019: expected one match in ${p}, got ${n}`);
  write(p,s.replace(oldText,newText));
}
function marker(p,m){if(!read(p).includes(m)) throw new Error(`TASK-019 baseline mismatch in ${p}: ${m}`)}

// Fail closed against the audited baseline.
marker('src/core/execution/authorization/SecureExecutionAuthorizationGate.ts','parameters?: Record<string, any>;');
marker('src/core/execution/authorization/SecureExecutionAuthorizationGate.ts','if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL")');
marker('src/core/execution/runtimes/TermuxRuntimeService.ts','const authResult = this.authorizeRequest(request, runtimeId);');
marker('src/core/brain/ControlledCapabilityExecution.ts','public async execute(request: IExecutionRequest): Promise<IExecutionResult>');
marker('src/core/brain/BrainCapabilityOrchestrator.ts','export interface IBrainCapabilityOrchestrator');
marker('src/core/brain/BrainRequestGateway.ts','export interface IBrainRequestGateway');
marker('orbis-server/ai/AIChatService.cjs','const matchedCapabilityId =');
marker('orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs','function match(message)');

for(const f of files) backup(f);
fs.copyFileSync(A(`${pkg}/src/core/execution/authorization/PendingApprovalStore.ts`),A('src/core/execution/authorization/PendingApprovalStore.ts'));

replaceOnce('src/core/execution/authorization/SecureExecutionAuthorizationGate.ts',
'  parameters?: Record<string, any>;\n',
'  parameters?: Record<string, any>;\n  /** TASK-019: set only after a validated one-time approval token is consumed. */\n  approvalGranted?: boolean;\n');
replaceOnce('src/core/execution/authorization/SecureExecutionAuthorizationGate.ts',
`    // SENSITIVE capability OR Policy requires approval\n    if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL") {\n      return this.requireApproval(request, "Action requires explicit approval");\n    }`,
`    // SENSITIVE capability OR Policy requires approval.\n    // TASK-019: approval does not bypass the checks above; it only satisfies\n    // the explicit human-confirmation condition after fresh authorization.\n    if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL") {\n      if (request.approvalGranted === true) {\n        return this.allow(request, "Authorization successful with explicit approval");\n      }\n      return this.requireApproval(request, "Action requires explicit approval");\n    }`);

replaceOnce('src/core/execution/runtimes/TermuxRuntimeService.ts',
'import { TermuxRuntime } from "./TermuxRuntime";\n',
'import { TermuxRuntime } from "./TermuxRuntime";\nimport { pendingApprovalStore } from "../authorization/PendingApprovalStore";\n');
replaceOnce('src/core/execution/runtimes/TermuxRuntimeService.ts',
'  private readonly policyEngine: ExecutionPolicyEngine;\n',
'  private readonly policyEngine: ExecutionPolicyEngine;\n  private readonly approvalStore = pendingApprovalStore;\n');
replaceOnce('src/core/execution/runtimes/TermuxRuntimeService.ts',
`    if (!authResult.authorized) {\n      return {\n        success: false,\n        requestId: request.requestId,\n        runtime: runtimeId,\n        error: \`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`,\n        durationMs: 0,\n      };\n    }\n\n    return this.runtime.execute(request);`,
`    if (!authResult.authorized) {\n      if (authResult.requiresApproval) {\n        const pending = this.approvalStore.create({ ...request, requestedRuntime: runtimeId });\n        return {\n          success: false,\n          requestId: request.requestId,\n          runtime: runtimeId,\n          error: \`AUTHORIZATION_REQUIRE_APPROVAL: \${authResult.reason}\`,\n          approvalRequired: true,\n          approvalToken: pending.token,\n          approvalExpiresAt: pending.expiresAt,\n          durationMs: 0,\n        };\n      }\n      return {\n        success: false,\n        requestId: request.requestId,\n        runtime: runtimeId,\n        error: \`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`,\n        durationMs: 0,\n      };\n    }\n\n    return this.runtime.execute(request);\n  }\n\n  public async resolveApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult> {\n    const resolved = this.approvalStore.resolve(token, decision);\n    if (resolved.resolution === "REJECTED") return { success:false, requestId:"approval-rejected", runtime:this.runtime.getName(), error:"APPROVAL_REJECTED", durationMs:0 };\n    if (resolved.resolution !== "APPROVED" || !resolved.request) return { success:false, requestId:"approval-invalid", runtime:this.runtime.getName(), error:\`APPROVAL_\${resolved.resolution}\`, durationMs:0 };\n\n    const request = resolved.request;\n    const status = await this.check();\n    if (!status.connected) return { success:false, requestId:request.requestId, runtime:this.runtime.getName(), error:"BRIDGE_UNREACHABLE: Cannot execute approved capability when bridge is disconnected.", durationMs:0 };\n\n    const runtimeId = request.requestedRuntime ?? this.runtime.getName();\n    const authResult = this.authorizeRequest(request, runtimeId, true);\n    if (!authResult.authorized) return { success:false, requestId:request.requestId, runtime:runtimeId, error:\`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`, durationMs:0 };\n    return this.runtime.execute(request);\n  }`);
replaceOnce('src/core/execution/runtimes/TermuxRuntimeService.ts',
`  private authorizeRequest(\n    request: IExecutionRequest,\n    runtimeId: string,\n  ): AuthorizationResult {`,
`  private authorizeRequest(\n    request: IExecutionRequest,\n    runtimeId: string,\n    approvalGranted = false,\n  ): AuthorizationResult {`);
replaceOnce('src/core/execution/runtimes/TermuxRuntimeService.ts',
`      capabilityId: request.capability,\n      parameters: request.input,\n    });`,
`      capabilityId: request.capability,\n      parameters: request.input,\n      approvalGranted,\n    });`);

if(!read('src/core/execution/interfaces/IExecutionResult.ts').includes('approvalToken')){
  replaceOnce('src/core/execution/interfaces/IExecutionResult.ts','  error?: string;','  error?: string;\n  approvalRequired?: boolean;\n  approvalToken?: string;\n  approvalExpiresAt?: number;');
}

replaceOnce('src/core/brain/ControlledCapabilityExecution.ts',
`export interface IControlledCapabilityExecution {\n  execute(request: IExecutionRequest): Promise<IExecutionResult>;\n}`,
`export interface IControlledCapabilityExecution {\n  execute(request: IExecutionRequest): Promise<IExecutionResult>;\n  resolveApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult>;\n}`);
replaceOnce('src/core/brain/ControlledCapabilityExecution.ts',
`    return result;\n  }\n}\n\nexport const controlledCapabilityExecution =`,
`    return result;\n  }\n\n  public async resolveApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult> {\n    return this.service.resolveApproval(token, decision);\n  }\n}\n\nexport const controlledCapabilityExecution =`);

replaceOnce('src/core/brain/BrainCapabilityOrchestrator.ts',
`  ): Promise<IExecutionResult>;\n}\n\nlet requestCounter`,
`  ): Promise<IExecutionResult>;\n  resolveApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult>;\n}\n\nlet requestCounter`);
replaceOnce('src/core/brain/BrainCapabilityOrchestrator.ts',
`  public async requestCapability(\n`,
`  public async resolveApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult> {\n    return this.execution.resolveApproval(token, decision);\n  }\n\n  public async requestCapability(\n`);

replaceOnce('src/core/brain/BrainRequestGateway.ts',
`export interface IBrainRequestGateway {\n  submit(request: RawBrainRequest): Promise<IExecutionResult>;\n}`,
`export interface IBrainRequestGateway {\n  submit(request: RawBrainRequest): Promise<IExecutionResult>;\n  submitApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult>;\n}`);
replaceOnce('src/core/brain/BrainRequestGateway.ts',
`  /**\n   * Validate -> normalize -> forward unchanged to`,
`  public async submitApproval(token: string, decision: "APPROVE" | "REJECT"): Promise<IExecutionResult> {\n    if (typeof token !== "string" || token.trim().length < 20) return buildValidationFailure(REASON_BRAIN_REQUEST_INVALID, "Invalid approval token");\n    return this.orchestrator.resolveApproval(token.trim(), decision);\n  }\n\n  /**\n   * Validate -> normalize -> forward unchanged to`);

replaceOnce('orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs',
`function match(message) {\n  const normalized = normalize(message);\n  if (!normalized) return null;\n\n  for (const entry of CAPABILITY_PHRASES) {\n    for (const phrase of entry.phrases) {\n      if (normalized.includes(normalize(phrase))) {\n        return entry.capabilityId;\n      }\n    }\n  }\n\n  return null;\n}\n`,
`function match(message) {\n  const normalized = normalize(message);\n  if (!normalized) return null;\n  for (const entry of CAPABILITY_PHRASES) {\n    for (const phrase of entry.phrases) {\n      if (normalized.includes(normalize(phrase))) return entry.capabilityId;\n    }\n  }\n  return null;\n}\n\nfunction matchRequest(message) {\n  const normalized = normalize(message);\n  const capabilityId = match(normalized);\n  if (!capabilityId) return null;\n  if (capabilityId === "termux.file.read") {\n    if (normalized.includes("package.json")) return { capabilityId, input:{path:"package.json"}, needsInput:false };\n    if (normalized.includes("readme.md")) return { capabilityId, input:{path:"README.md"}, needsInput:false };\n    return { capabilityId, input:null, needsInput:true };\n  }\n  return { capabilityId, input:{}, needsInput:false };\n}\n\nconst APPROVAL_TOKEN = /(?:token|approval|অনুমোদন|টোকেন)\\s*[:#]?\\s*([A-Za-z0-9_-]{20,})/i;\nfunction matchApprovalDecision(message) {\n  const token = String(message||"").match(APPROVAL_TOKEN)?.[1] || null;\n  if (!token) return null;\n  const approve = /\\b(approve|approved|yes|confirm|confirmed)\\b/i.test(message) || /(?:হ্যাঁ|অনুমোদন|ঠিক আছে|অনুমতি দাও)/i.test(message);\n  const reject = /\\b(reject|rejected|deny|denied|no|cancel|cancelled)\\b/i.test(message) || /(?:না|বাতিল|প্রত্যাখ্যান)/i.test(message);\n  if (approve === reject) return null;\n  return { token, decision: approve ? "APPROVE" : "REJECT" };\n}\n`);
replaceOnce('orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs','module.exports = { match, detectLanguage };','module.exports = { match, matchRequest, matchApprovalDecision, detectLanguage };');

// AIChatService: approval resolution before ordinary capability routing.
replaceOnce('orbis-server/ai/AIChatService.cjs',
`      // ---------------------------------------------------------\n      // STEP 1.5 (TASK-013): DETERMINISTIC BRAIN CAPABILITY REQUEST\n`,
`      // ---------------------------------------------------------\n      // TASK-019: explicit approval. Bare yes/হ্যাঁ never authorizes.\n      // ---------------------------------------------------------\n      const approvalDecision = capabilityIntentMatcher.matchApprovalDecision(lastUserMessage);\n      if (approvalDecision) {\n        const gateway = loadBrainRequestGateway();\n        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);\n        if (!gateway || typeof gateway.submitApproval !== "function") {\n          return { message:{role:"assistant",content:lang === "bn" ? "অনুমোদন সিস্টেম এই মুহূর্তে উপলব্ধ নয়।" : "The approval system is unavailable right now."}, provider:{name:"ORBIS Brain",type:"BRAIN_APPROVAL"} };\n        }\n        const result = await gateway.submitApproval(approvalDecision.token, approvalDecision.decision);\n        return { message:{role:"assistant",content:formatApprovalResultAsChatReply(result,lang)}, provider:{name:"ORBIS Brain",type:"BRAIN_APPROVAL"} };\n      }\n\n      // ---------------------------------------------------------\n      // STEP 1.5 (TASK-013): DETERMINISTIC BRAIN CAPABILITY REQUEST\n`);
replaceOnce('orbis-server/ai/AIChatService.cjs',
`      const matchedCapabilityId =\n        capabilityIntentMatcher.match(lastUserMessage);\n\n      if (matchedCapabilityId) {`,
`      const capabilityRequest = capabilityIntentMatcher.matchRequest(lastUserMessage);\n      const matchedCapabilityId = capabilityRequest?.capabilityId ?? null;\n\n      if (matchedCapabilityId) {`);
replaceOnce('orbis-server/ai/AIChatService.cjs',
`        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);\n\n        if (!brainRequestGateway) {`,
`        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);\n\n        if (capabilityRequest.needsInput) {\n          return { message:{role:"assistant",content:lang === "bn" ? "কোন allow-listed ফাইলটি পড়ব বলুন: package.json অথবা README.md।" : "Which allow-listed file should I read: package.json or README.md?"}, provider:{name:"ORBIS Brain",type:"BRAIN_CAPABILITY"} };\n        }\n\n        if (!brainRequestGateway) {`);
replaceOnce('orbis-server/ai/AIChatService.cjs','          input: {},','          input: capabilityRequest.input || {},');

replaceOnce('orbis-server/ai/AIChatService.cjs',
`  if (error.includes("REQUIRE_APPROVAL")) {\n    return bn\n      ? "এই অনুরোধের জন্য অনুমোদন প্রয়োজন, তাই এটি এখনই কার্যকর করা হয়নি।"\n      : "This request requires approval, so it was not executed yet.";\n  }`,
`  if (error.includes("REQUIRE_APPROVAL")) {\n    const token = result && result.approvalToken;\n    if (token) {\n      return bn\n        ? \`এই অনুরোধের জন্য আপনার অনুমোদন প্রয়োজন।\\n\\nApproval token: \${token}\\n\\nঅনুমোদন করতে লিখুন: APPROVE \${token}\`\n        : \`This request requires your approval.\\n\\nApproval token: \${token}\\n\\nTo approve this exact request, reply: APPROVE \${token}\`;\n    }\n    return bn ? "এই অনুরোধের জন্য অনুমোদন প্রয়োজন, তাই এটি এখনই কার্যকর করা হয়নি।" : "This request requires approval, so it was not executed yet.";\n  }`);

replaceOnce('orbis-server/ai/AIChatService.cjs',
`class AIChatService {`,
`function formatApprovalResultAsChatReply(result, lang) {\n  const bn = lang === "bn";\n  const error = result?.error || "";\n  if (result?.success) return bn ? "অনুমোদিত অনুরোধটি সফলভাবে কার্যকর হয়েছে।" : "The approved request was executed successfully.";\n  if (error.includes("APPROVAL_REJECTED")) return bn ? "অনুরোধটি বাতিল করা হয়েছে এবং কার্যকর করা হয়নি।" : "The request was rejected and was not executed.";\n  if (error.includes("APPROVAL_EXPIRED")) return bn ? "অনুমোদনের সময় শেষ হয়ে গেছে। নতুন করে অনুরোধ করুন।" : "The approval expired. Please make the request again.";\n  if (error.includes("APPROVAL_REPLAY")) return bn ? "এই approval token ইতিমধ্যে ব্যবহার করা হয়েছে।" : "This approval token has already been used.";\n  if (error.includes("APPROVAL_INVALID")) return bn ? "Approval tokenটি বৈধ নয়।" : "That approval token is not valid.";\n  return bn ? \`অনুমোদন সম্পন্ন হয়নি: \${error || "UNKNOWN_ERROR"}\` : \`The approval flow did not complete: \${error || "UNKNOWN_ERROR"}\`;\n}\n\nclass AIChatService {`);

console.log('\nTASK-019 source changes applied locally. No git operations performed.');
console.log('Next: npm run type-check && npm test && npm run build');
console.log('Then inspect: git diff --check && git diff');
