#!/usr/bin/env node
import fs from 'node:fs'; import path from 'node:path';
const root=process.cwd(); const files=[
'src/core/execution/authorization/SecureExecutionAuthorizationGate.ts','src/core/execution/runtimes/TermuxRuntimeService.ts','src/core/execution/interfaces/IExecutionResult.ts','src/core/brain/ControlledCapabilityExecution.ts','src/core/brain/BrainCapabilityOrchestrator.ts','src/core/brain/BrainRequestGateway.ts','orbis-server/ai/AIChatService.cjs','orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs'];
for(const f of files){const d=path.dirname(path.join(root,f));const b=path.basename(f);const c=fs.readdirSync(d).filter(x=>x.startsWith(b+'.task019-backup-')).sort().reverse();if(c.length){fs.copyFileSync(path.join(d,c[0]),path.join(root,f));console.log('RESTORE',f)}else console.log('SKIP',f)}
const n=path.join(root,'src/core/execution/authorization/PendingApprovalStore.ts');if(fs.existsSync(n)){fs.unlinkSync(n);console.log('DELETE',n)}
