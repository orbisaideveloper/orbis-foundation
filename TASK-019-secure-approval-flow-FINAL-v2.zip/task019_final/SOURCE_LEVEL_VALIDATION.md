# TASK-019 Final Source-Level Validation

## Baseline reviewed

The implementation was designed against the current `main` source for:

- `SecureExecutionAuthorizationGate.ts`
- `TermuxRuntimeService.ts`
- `TermuxRuntime.ts`
- `IExecutionResult.ts`
- `ControlledCapabilityExecution.ts`
- `BrainCapabilityOrchestrator.ts`
- `BrainRequestGateway.ts`
- `AIChatService.cjs`
- `ChatCapabilityIntentMatcher.cjs`

## Security decisions

1. `PRIVILEGED` remains unconditional DENY.
2. `SENSITIVE` remains REQUIRE_APPROVAL unless `approvalGranted` is present.
3. `approvalGranted` is never supplied by the chat user; it is set only after
   a valid one-time approval token resolves to the immutable stored request.
4. The approval store uses cryptographically random bearer tokens, a 3-minute
   TTL, one-time consumption, and request snapshot binding.
5. Approval performs a fresh runtime/health/policy/authorization check before
   execution.
6. `termux.file.read` continues to use the TASK-018 hardcoded bridge allow-list.
7. Termux now forwards the validated capability input to the bridge.
8. A bare `yes` / `হ্যাঁ` is not an approval command.
9. The AI provider/Ollama path is not used to authorize or execute approvals.
10. No Git operation is performed by the installer or rollback script.

## Installer safety

- All target files are read and transformed in memory first.
- Baseline markers are checked before writing.
- Replacement counts must be exactly one.
- A `--dry-run` mode performs all replacement checks without writing.
- Backups are created immediately before the final write.
- A manifest records backups for deterministic rollback.

## Validation performed here

- Node syntax check passed for the installer.
- Node syntax check passed for the rollback script.
- Node syntax check passed for the CJS matcher test.
- Static inspection confirmed no Git command is invoked.
- Static inspection confirmed the final authorization path re-runs the gate.

## Validation that must still run in Termux

This package cannot honestly claim the user's installed dependency graph,
TypeScript compiler, Vitest environment, generated Brain runtime, or actual
Termux/bridge process were executed here. After dry-run/apply, run the
repository's real checks:

```bash
node --check orbis-server/ai/AIChatService.cjs
node --check orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs
npm run build
npm test
npm run lint
npm run check:circular
git diff --check
git status --short
```

Only after all of those pass should TASK-019 be committed/pushed from Termux.
