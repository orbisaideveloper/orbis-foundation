# ORBIS TASK-019 — Secure Capability Approval Flow (Final)

This package is a **Termux-only installer** for TASK-019. It was designed
against the ORBIS `main` source baseline reviewed before packaging.

## Safety

- No Git commands are executed.
- The installer stages every source transformation in memory first.
- If any audited baseline marker is missing, it aborts before writing.
- Existing target files are backed up before the final write.
- A manifest records the backup paths.
- `rollback-task-019.mjs` restores the backed-up files and removes the
  TASK-019-created files.
- The existing `PRIVILEGED` hard-deny remains unconditional.
- `SENSITIVE` still requires approval. `approvalGranted` is accepted only
  on the immutable request returned by a one-time, expiring approval token.
- The approval flow does not use Ollama to authorize anything.
- A bare `yes` / `হ্যাঁ` is never enough to approve.

## Intended flow

Chat request -> deterministic Brain capability match -> policy/auth gate ->
approval token -> explicit `APPROVE <token>` -> token consumed -> fresh
policy/auth checks -> Termux runtime -> allow-listed bridge handler -> chat.

For TASK-018 file reads, only `package.json` and `README.md` are selectable.

## Apply

From the ORBIS repository root:

```bash
node TASK-019-secure-approval-flow/apply-task-019.mjs
```

Then validate before any commit:

```bash
node --check orbis-server/ai/AIChatService.cjs
node --check orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs
npm run build
npm test
npm run lint
npm run check:circular
git diff --check
git status --short
```

Do not push until the complete validation output has been reviewed.

## Rollback

If validation fails:

```bash
node TASK-019-secure-approval-flow/rollback-task-019.mjs
```

The rollback uses the install manifest created by the installer and restores
the exact pre-install files.
