#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const manifestPath = path.join(
  ROOT,
  "TASK-019-secure-approval-flow",
  ".task019-manifest.json",
);

if (!fs.existsSync(manifestPath)) {
  throw new Error("TASK-019 rollback manifest not found. Nothing was restored.");
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));

for (const item of manifest.backups) {
  if (!fs.existsSync(item.backupPath)) {
    throw new Error(`Missing backup for ${item.file}: ${item.backupPath}`);
  }
}

for (const item of manifest.backups) {
  fs.copyFileSync(item.backupPath, path.join(ROOT, item.file));
}

for (const file of manifest.createdFiles) {
  const destination = path.join(ROOT, file);
  if (fs.existsSync(destination)) fs.rmSync(destination, { force: true });
}

fs.rmSync(manifestPath, { force: true });

for (const item of manifest.backups) {
  fs.rmSync(item.backupPath, { force: true });
}

console.log("TASK-019 rollback completed. Git state was not modified.");
