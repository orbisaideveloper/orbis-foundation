import { randomBytes } from "node:crypto";
import { IExecutionRequest } from "../interfaces/IExecutionRequest";

export type PendingApprovalDecision = "APPROVE" | "REJECT";

export interface PendingApprovalRecord {
  token: string;
  request: IExecutionRequest;
  requestedRuntime: string;
  createdAt: number;
  expiresAt: number;
  consumed: boolean;
}

export type ApprovalResolution =
  | { resolution: "APPROVED"; request: IExecutionRequest }
  | { resolution: "REJECTED" }
  | { resolution: "EXPIRED" }
  | { resolution: "REPLAY" }
  | { resolution: "INVALID" };

const DEFAULT_TTL_MS = 3 * 60 * 1000;

function cloneRequest(request: IExecutionRequest): IExecutionRequest {
  return {
    ...request,
    input: { ...(request.input || {}) },
    metadata: request.metadata ? { ...request.metadata } : undefined,
  };
}

export class PendingApprovalStore {
  private readonly pending = new Map<string, PendingApprovalRecord>();
  private readonly ttlMs: number;

  constructor(ttlMs = DEFAULT_TTL_MS) {
    if (!Number.isFinite(ttlMs) || ttlMs <= 0) {
      throw new Error("Approval TTL must be a positive finite number.");
    }
    this.ttlMs = ttlMs;
  }

  public create(request: IExecutionRequest): PendingApprovalRecord {
    if (!request?.requestId || !request.capability || !request.requestedRuntime) {
      throw new Error("Cannot create approval for an incomplete execution request.");
    }

    const now = Date.now();
    const token = randomBytes(32).toString("base64url");
    const record: PendingApprovalRecord = {
      token,
      request: cloneRequest(request),
      requestedRuntime: request.requestedRuntime,
      createdAt: now,
      expiresAt: now + this.ttlMs,
      consumed: false,
    };

    this.pending.set(token, record);
    this.purgeExpired(now);
    return { ...record, request: cloneRequest(record.request) };
  }

  public resolve(
    token: string,
    decision: PendingApprovalDecision,
  ): ApprovalResolution {
    if (typeof token !== "string" || token.length < 20) {
      return { resolution: "INVALID" };
    }

    const record = this.pending.get(token);
    if (!record) return { resolution: "INVALID" };

    if (record.consumed) {
      this.pending.delete(token);
      return { resolution: "REPLAY" };
    }

    if (Date.now() >= record.expiresAt) {
      record.consumed = true;
      this.pending.delete(token);
      return { resolution: "EXPIRED" };
    }

    // Every decision consumes the token exactly once. REJECT never reaches
    // the runtime, and APPROVE returns only the immutable request snapshot
    // that was originally approved.
    record.consumed = true;
    this.pending.delete(token);

    if (decision === "REJECT") return { resolution: "REJECTED" };

    if (decision !== "APPROVE") return { resolution: "INVALID" };

    return {
      resolution: "APPROVED",
      request: cloneRequest(record.request),
    };
  }

  public size(): number {
    this.purgeExpired(Date.now());
    return this.pending.size;
  }

  private purgeExpired(now: number): void {
    for (const [token, record] of this.pending) {
      if (record.expiresAt <= now) this.pending.delete(token);
    }
  }
}

export const pendingApprovalStore = new PendingApprovalStore();
