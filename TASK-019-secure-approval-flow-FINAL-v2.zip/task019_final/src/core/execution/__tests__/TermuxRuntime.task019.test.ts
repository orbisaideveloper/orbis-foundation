import { describe, expect, it, vi } from "vitest";
import { TermuxRuntime } from "../runtimes/TermuxRuntime";

describe("TASK-019 TermuxRuntime input forwarding", () => {
  it("forwards the exact validated capability input to the bridge", async () => {
    const fetchMock = vi.fn()
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          identity: { valid: true },
          capabilities: [{ id: "termux.system.info" }, { id: "termux.file.read" }],
          status: "CAPABILITIES_VERIFIED",
        }),
      })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          success: true,
          data: { path: "package.json", content: "{}" },
        }),
      });

    vi.stubGlobal("fetch", fetchMock);

    const runtime = new TermuxRuntime();
    await runtime.performHandshake();

    const result = await runtime.execute({
      requestId: "test-runtime-1",
      capability: "termux.file.read",
      input: { path: "package.json" },
    });

    expect(result.success).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(2);

    const executeCall = fetchMock.mock.calls[1];
    const options = executeCall[1];
    expect(JSON.parse(options.body)).toEqual({
      capability: "termux.file.read",
      input: { path: "package.json" },
    });

    vi.unstubAllGlobals();
  });
});
