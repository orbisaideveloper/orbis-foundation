import { describe, expect, it, vi } from "vitest";
import { PendingApprovalStore } from "../authorization/PendingApprovalStore";

const request = {
  requestId: "brain-req-test-1",
  capability: "termux.file.read",
  input: { path: "package.json" },
  requestedRuntime: "TermuxRuntime",
};

describe("TASK-019 PendingApprovalStore", () => {
  it("creates a high-entropy token bound to the original request and approves once", () => {
    const store = new PendingApprovalStore(60_000);
    const pending = store.create(request);

    expect(pending.token).toHaveLength(43);
    expect(pending.request.input).toEqual({ path: "package.json" });

    const approved = store.resolve(pending.token, "APPROVE");
    expect(approved.resolution).toBe("APPROVED");
    if (approved.resolution === "APPROVED") {
      expect(approved.request.capability).toBe("termux.file.read");
      expect(approved.request.input).toEqual({ path: "package.json" });
    }

    expect(store.resolve(pending.token, "APPROVE").resolution).toBe("INVALID");
  });

  it("consumes rejected approvals and never executes them", () => {
    const store = new PendingApprovalStore(60_000);
    const pending = store.create(request);

    expect(store.resolve(pending.token, "REJECT").resolution).toBe("REJECTED");
    expect(store.resolve(pending.token, "APPROVE").resolution).toBe("INVALID");
  });

  it("expires approvals fail-closed", () => {
    vi.useFakeTimers();
    const store = new PendingApprovalStore(1);
    const pending = store.create(request);

    vi.advanceTimersByTime(5);
    expect(store.resolve(pending.token, "APPROVE").resolution).toBe("EXPIRED");

    vi.useRealTimers();
  });
});
