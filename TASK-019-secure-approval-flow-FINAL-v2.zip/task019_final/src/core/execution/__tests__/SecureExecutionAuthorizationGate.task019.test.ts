import { describe, expect, it } from "vitest";
import {
  AuthorizationDecision,
  SecureExecutionAuthorizationGate,
} from "../authorization/SecureExecutionAuthorizationGate";

const deps = {
  registry: {
    hasRuntime: () => true,
    hasCapability: () => true,
    isCapabilityEnabled: () => true,
    getCapabilityRiskLevel: () => "SENSITIVE" as const,
  },
  lifecycle: {
    isReady: () => true,
    isHealthy: () => true,
  },
  policy: {
    evaluate: () => "REQUIRE_APPROVAL" as const,
  },
};

describe("TASK-019 SecureExecutionAuthorizationGate", () => {
  it("still requires approval for SENSITIVE requests without approvalGranted", () => {
    const gate = new SecureExecutionAuthorizationGate(
      deps.registry,
      deps.lifecycle,
      deps.policy,
    );

    const result = gate.authorize({
      runtimeId: "TermuxRuntime",
      capabilityId: "termux.file.read",
      parameters: { path: "package.json" },
    });

    expect(result.authorized).toBe(false);
    expect(result.decision).toBe(AuthorizationDecision.REQUIRE_APPROVAL);
    expect(result.requiresApproval).toBe(true);
  });

  it("allows only an already-approved request after all fresh checks pass", () => {
    const gate = new SecureExecutionAuthorizationGate(
      deps.registry,
      deps.lifecycle,
      deps.policy,
    );

    const result = gate.authorize({
      runtimeId: "TermuxRuntime",
      capabilityId: "termux.file.read",
      parameters: { path: "package.json" },
      approvalGranted: true,
    });

    expect(result.authorized).toBe(true);
    expect(result.decision).toBe(AuthorizationDecision.AUTHORIZED);
  });

  it("still denies a privileged capability even with approvalGranted", () => {
    const privilegedDeps = {
      ...deps,
      registry: {
        ...deps.registry,
        getCapabilityRiskLevel: () => "PRIVILEGED" as const,
      },
    };

    const gate = new SecureExecutionAuthorizationGate(
      privilegedDeps.registry,
      privilegedDeps.lifecycle,
      privilegedDeps.policy,
    );

    const result = gate.authorize({
      runtimeId: "TermuxRuntime",
      capabilityId: "termux.secret",
      parameters: {},
      approvalGranted: true,
    });

    expect(result.authorized).toBe(false);
    expect(result.decision).toBe(AuthorizationDecision.DENIED);
  });
});
