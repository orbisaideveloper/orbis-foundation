#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const PKG = "TASK-019-secure-approval-flow";
const now = new Date().toISOString().replace(/[:.]/g, "-");

const targets = [
  "src/core/execution/authorization/SecureExecutionAuthorizationGate.ts",
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  "src/core/execution/interfaces/IExecutionResult.ts",
  "src/core/execution/runtimes/TermuxRuntime.ts",
  "src/core/brain/ControlledCapabilityExecution.ts",
  "src/core/brain/BrainCapabilityOrchestrator.ts",
  "src/core/brain/BrainRequestGateway.ts",
  "orbis-server/ai/AIChatService.cjs",
  "orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs",
];

const A = (p) => path.join(ROOT, p);
const read = (p) => fs.readFileSync(A(p), "utf8");

const staged = new Map();
for (const file of targets) staged.set(file, read(file));

function get(file) {
  return staged.get(file);
}

function set(file, content) {
  staged.set(file, content);
}

function replaceOnce(file, oldText, newText) {
  const source = get(file);
  const count = source.split(oldText).length - 1;
  if (count !== 1) {
    throw new Error(`TASK-019 baseline mismatch in ${file}: expected 1 match, got ${count}`);
  }
  set(file, source.replace(oldText, newText));
}

function requireMarker(file, marker) {
  if (!get(file).includes(marker)) {
    throw new Error(`TASK-019 baseline marker missing in ${file}: ${marker}`);
  }
}

function hasMarker(file, marker) {
  return get(file).includes(marker);
}

// Fail closed against the audited GitHub main baseline.
requireMarker(
  "src/core/execution/authorization/SecureExecutionAuthorizationGate.ts",
  'if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL")',
);
requireMarker(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  "const authResult = this.authorizeRequest(request, runtimeId);",
);
requireMarker(
  "src/core/execution/runtimes/TermuxRuntime.ts",
  "body: JSON.stringify({ capability: request.capability }),",
);
requireMarker(
  "src/core/brain/ControlledCapabilityExecution.ts",
  "public async execute(request: IExecutionRequest): Promise<IExecutionResult>",
);
requireMarker(
  "src/core/brain/BrainCapabilityOrchestrator.ts",
  "public async requestCapability(",
);
requireMarker(
  "src/core/brain/BrainRequestGateway.ts",
  "public async submit(request: RawBrainRequest): Promise<IExecutionResult>",
);
requireMarker(
  "orbis-server/ai/AIChatService.cjs",
  "const matchedCapabilityId =",
);
requireMarker(
  "orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs",
  "function match(message)",
);

if (hasMarker("src/core/execution/authorization/SecureExecutionAuthorizationGate.ts", "approvalGranted?: boolean;")) {
  throw new Error("TASK-019 appears to be already applied to the authorization gate. Aborting.");
}
if (hasMarker("src/core/brain/BrainRequestGateway.ts", "submitApproval(token")) {
  throw new Error("TASK-019 appears to be already applied to BrainRequestGateway. Aborting.");
}
if (hasMarker("orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs", "matchApprovalDecision")) {
  throw new Error("TASK-019 appears to be already applied to ChatCapabilityIntentMatcher. Aborting.");
}

replaceOnce(
  "src/core/execution/authorization/SecureExecutionAuthorizationGate.ts",
  "  parameters?: Record<string, any>;\n",
  "  parameters?: Record<string, any>;\n  /** TASK-019: true only after a validated, one-time approval token is consumed. */\n  approvalGranted?: boolean;\n",
);

replaceOnce(
  "src/core/execution/authorization/SecureExecutionAuthorizationGate.ts",
  `    // SENSITIVE capability OR Policy requires approval
    if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL") {
      return this.requireApproval(request, "Action requires explicit approval");
    }`,
  `    // SENSITIVE capability OR Policy requires approval.
    // TASK-019 does not remove the SENSITIVE gate. It only permits the
    // already-approved, immutable request to pass after ALL checks above
    // have been freshly evaluated again.
    if (riskLevel === "SENSITIVE" || policyDecision === "REQUIRE_APPROVAL") {
      if (request.approvalGranted === true) {
        return this.allow(
          request,
          "Authorization successful with explicit approval",
        );
      }
      return this.requireApproval(request, "Action requires explicit approval");
    }`,
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  'import { TermuxRuntime } from "./TermuxRuntime";\n',
  'import { TermuxRuntime } from "./TermuxRuntime";\nimport { pendingApprovalStore } from "../authorization/PendingApprovalStore";\n',
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  "  private readonly policyEngine: ExecutionPolicyEngine;\n",
  "  private readonly policyEngine: ExecutionPolicyEngine;\n  private readonly approvalStore = pendingApprovalStore;\n",
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  `    if (!authResult.authorized) {
      return {
        success: false,
        requestId: request.requestId,
        runtime: runtimeId,
        error: \`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`,
        durationMs: 0,
      };
    }

    return this.runtime.execute(request);`,
  `    if (!authResult.authorized) {
      if (authResult.requiresApproval) {
        const pending = this.approvalStore.create({
          ...request,
          requestedRuntime: runtimeId,
        });
        return {
          success: false,
          requestId: request.requestId,
          runtime: runtimeId,
          error: \`AUTHORIZATION_REQUIRE_APPROVAL: \${authResult.reason}\`,
          approvalRequired: true,
          approvalToken: pending.token,
          approvalExpiresAt: pending.expiresAt,
          durationMs: 0,
        };
      }

      return {
        success: false,
        requestId: request.requestId,
        runtime: runtimeId,
        error: \`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`,
        durationMs: 0,
      };
    }

    return this.runtime.execute(request);
  }

  public async resolveApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult> {
    const resolved = this.approvalStore.resolve(token, decision);

    if (resolved.resolution === "REJECTED") {
      return {
        success: false,
        requestId: "approval-rejected",
        runtime: this.runtime.getName(),
        error: "APPROVAL_REJECTED",
        durationMs: 0,
      };
    }

    if (resolved.resolution !== "APPROVED" || !resolved.request) {
      return {
        success: false,
        requestId: "approval-invalid",
        runtime: this.runtime.getName(),
        error: \`APPROVAL_\${resolved.resolution}\`,
        durationMs: 0,
      };
    }

    const request = resolved.request;
    const status = await this.check();

    if (!status.connected) {
      return {
        success: false,
        requestId: request.requestId,
        runtime: this.runtime.getName(),
        error:
          "BRIDGE_UNREACHABLE: Cannot execute approved capability when bridge is disconnected.",
        durationMs: 0,
      };
    }

    const runtimeId = request.requestedRuntime ?? this.runtime.getName();
    const authResult = this.authorizeRequest(request, runtimeId, true);

    if (!authResult.authorized) {
      return {
        success: false,
        requestId: request.requestId,
        runtime: runtimeId,
        error: \`AUTHORIZATION_\${authResult.decision}: \${authResult.reason}\`,
        durationMs: 0,
      };
    }

    const executionResult = await this.runtime.execute(request);
    return {
      ...executionResult,
      metadata: {
        ...(executionResult.metadata || {}),
        capabilityId: request.capability,
      },
    };
  }`,
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  `  private authorizeRequest(
    request: IExecutionRequest,
    runtimeId: string,
  ): AuthorizationResult {`,
  `  private authorizeRequest(
    request: IExecutionRequest,
    runtimeId: string,
    approvalGranted = false,
  ): AuthorizationResult {`,
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntimeService.ts",
  `      capabilityId: request.capability,
      parameters: request.input,
    });`,
  `      capabilityId: request.capability,
      parameters: request.input,
      approvalGranted,
    });`,
);

replaceOnce(
  "src/core/execution/runtimes/TermuxRuntime.ts",
  "body: JSON.stringify({ capability: request.capability }),",
  "body: JSON.stringify({ capability: request.capability, input: request.input || {} }),",
);

replaceOnce(
  "src/core/execution/interfaces/IExecutionResult.ts",
  "  error?: string;\n",
  "  error?: string;\n  approvalRequired?: boolean;\n  approvalToken?: string;\n  approvalExpiresAt?: number;\n",
);

replaceOnce(
  "src/core/brain/ControlledCapabilityExecution.ts",
  `export interface IControlledCapabilityExecution {
  execute(request: IExecutionRequest): Promise<IExecutionResult>;
}`,
  `export interface IControlledCapabilityExecution {
  execute(request: IExecutionRequest): Promise<IExecutionResult>;
  resolveApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult>;
}`,
);

replaceOnce(
  "src/core/brain/ControlledCapabilityExecution.ts",
  `    return result;
  }
}

export const controlledCapabilityExecution =`,
  `    return result;
  }

  public async resolveApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult> {
    return this.service.resolveApproval(token, decision);
  }
}

export const controlledCapabilityExecution =`,
);

replaceOnce(
  "src/core/brain/BrainCapabilityOrchestrator.ts",
  `  requestCapability(
    capabilityId: string,
    input: Record<string, any>,
    options?: RequestCapabilityOptions,
  ): Promise<IExecutionResult>;
}`,
  `  requestCapability(
    capabilityId: string,
    input: Record<string, any>,
    options?: RequestCapabilityOptions,
  ): Promise<IExecutionResult>;
  resolveApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult>;
}`,
);

replaceOnce(
  "src/core/brain/BrainCapabilityOrchestrator.ts",
  `  public async requestCapability(
`,
  `  public async resolveApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult> {
    return this.execution.resolveApproval(token, decision);
  }

  public async requestCapability(
`,
);

replaceOnce(
  "src/core/brain/BrainRequestGateway.ts",
  `export interface IBrainRequestGateway {
  submit(request: RawBrainRequest): Promise<IExecutionResult>;
}`,
  `export interface IBrainRequestGateway {
  submit(request: RawBrainRequest): Promise<IExecutionResult>;
  submitApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult>;
}`,
);

replaceOnce(
  "src/core/brain/BrainRequestGateway.ts",
  `  /**\n   * Validate -> normalize -> forward unchanged to`,
  `  public async submitApproval(
    token: string,
    decision: "APPROVE" | "REJECT",
  ): Promise<IExecutionResult> {
    if (typeof token !== "string" || token.trim().length < 20) {
      return buildValidationFailure(
        REASON_BRAIN_REQUEST_INVALID,
        "Invalid approval token",
      );
    }
    if (decision !== "APPROVE" && decision !== "REJECT") {
      return buildValidationFailure(
        REASON_BRAIN_REQUEST_INVALID,
        "Invalid approval decision",
      );
    }
    return this.orchestrator.resolveApproval(token.trim(), decision);
  }

  /**\n   * Validate -> normalize -> forward unchanged to`,
);

const matcherOld = `function match(message) {
  const normalized = normalize(message);
  if (!normalized) return null;

  for (const entry of CAPABILITY_PHRASES) {
    for (const phrase of entry.phrases) {
      if (normalized.includes(normalize(phrase))) {
        return entry.capabilityId;
      }
    }
  }

  return null;
}

`;

const matcherNew = `function match(message) {
  const normalized = normalize(message);
  if (!normalized) return null;

  for (const entry of CAPABILITY_PHRASES) {
    for (const phrase of entry.phrases) {
      if (normalized.includes(normalize(phrase))) {
        return entry.capabilityId;
      }
    }
  }

  return null;
}

function matchRequest(message) {
  const normalized = normalize(message);
  if (!normalized) return null;

  // Exact allow-listed file names are accepted only with an explicit
  // read/show/open intent. The matcher never accepts arbitrary filesystem
  // paths; bridge.cjs remains the final hard allow-list boundary.
  const fileIntent =
    /(read|show|open|display|পড়|দেখাও|খুলে|খোল)/i.test(normalized);

  if (fileIntent && normalized.includes("package.json")) {
    return {
      capabilityId: "termux.file.read",
      input: { path: "package.json" },
      needsInput: false,
    };
  }

  if (fileIntent && normalized.includes("readme.md")) {
    return {
      capabilityId: "termux.file.read",
      input: { path: "README.md" },
      needsInput: false,
    };
  }

  const capabilityId = match(normalized);
  if (!capabilityId) return null;

  if (capabilityId === "termux.file.read") {
    return { capabilityId, input: null, needsInput: true };
  }

  return { capabilityId, input: {}, needsInput: false };
}

const APPROVAL_TOKEN =
  /(?:approve|approved|confirm|confirmed|yes|reject|rejected|deny|denied|no|cancel|cancelled|approval|token|অনুমোদন|টোকেন|হ্যাঁ|ঠিক\\s+আছে|না|বাতিল|প্রত্যাখ্যান)\\s*[:#]?\\s*([A-Za-z0-9_-]{20,})/i;

function matchApprovalDecision(message) {
  const text = String(message || "");
  const matchResult = text.match(APPROVAL_TOKEN);
  const token = matchResult?.[1] || null;
  if (!token) return null;

  const approve =
    /\\b(approve|approved|yes|confirm|confirmed)\\b/i.test(text) ||
    /(?:হ্যাঁ|অনুমোদন|ঠিক আছে|অনুমতি দাও)/i.test(text);

  const reject =
    /\\b(reject|rejected|deny|denied|no|cancel|cancelled)\\b/i.test(text) ||
    /(?:না|বাতিল|প্রত্যাখ্যান)/i.test(text);

  if (approve === reject) return null;
  return { token, decision: approve ? "APPROVE" : "REJECT" };
}

`;

replaceOnce(
  "orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs",
  matcherOld,
  matcherNew,
);

replaceOnce(
  "orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs",
  "module.exports = { match, detectLanguage };",
  "module.exports = { match, matchRequest, matchApprovalDecision, detectLanguage };",
);

const chatStepOld = `      // ---------------------------------------------------------
      // STEP 1.5 (TASK-013): DETERMINISTIC BRAIN CAPABILITY REQUEST
      //
      // Only a fixed, hardcoded phrase (never AI-generated text) can
      // select a capabilityId here. If matched, the final ALLOW / DENY /
      // REQUIRE_APPROVAL decision belongs entirely to the existing
      // TASK-009 -> TASK-012 Brain chain via brainRequestGateway.submit()
      // — nothing here executes anything itself. A matched-but-denied
      // request is reported as denied and does NOT fall through to
      // web search or Ollama. An unmatched message falls through
      // unchanged to STEP 2.
      // ---------------------------------------------------------
      const matchedCapabilityId =
        capabilityIntentMatcher.match(lastUserMessage);

      if (matchedCapabilityId) {`;

const chatStepNew = `      // ---------------------------------------------------------
      // TASK-019: explicit approval resolution happens before normal
      // capability routing. A bare "yes"/"হ্যাঁ" never authorizes anything.
      // ---------------------------------------------------------
      const approvalDecision =
        capabilityIntentMatcher.matchApprovalDecision(lastUserMessage);

      if (approvalDecision) {
        const approvalGateway = loadBrainRequestGateway();
        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);

        if (!approvalGateway || typeof approvalGateway.submitApproval !== "function") {
          return {
            message: {
              role: "assistant",
              content:
                lang === "bn"
                  ? "অনুমোদন সিস্টেম এই মুহূর্তে উপলব্ধ নয়।"
                  : "The approval system is unavailable right now.",
            },
            provider: { name: "ORBIS Brain", type: "BRAIN_APPROVAL" },
          };
        }

        const approvalResult = await approvalGateway.submitApproval(
          approvalDecision.token,
          approvalDecision.decision,
        );

        return {
          message: {
            role: "assistant",
            content: formatApprovalResultAsChatReply(approvalResult, lang),
          },
          provider: { name: "ORBIS Brain", type: "BRAIN_APPROVAL" },
        };
      }

      // ---------------------------------------------------------
      // STEP 1.5 (TASK-013): DETERMINISTIC BRAIN CAPABILITY REQUEST
      //
      // Only a fixed, hardcoded phrase (never AI-generated text) can
      // select a capabilityId here. If matched, the final ALLOW / DENY /
      // REQUIRE_APPROVAL decision belongs entirely to the existing
      // TASK-009 -> TASK-012 Brain chain via brainRequestGateway.submit()
      // — nothing here executes anything itself. A matched-but-denied
      // request is reported as denied and does NOT fall through to
      // web search or Ollama. An unmatched message falls through
      // unchanged to STEP 2.
      // ---------------------------------------------------------
      const capabilityRequest =
        capabilityIntentMatcher.matchRequest(lastUserMessage);
      const matchedCapabilityId = capabilityRequest?.capabilityId ?? null;

      if (matchedCapabilityId) {`;

replaceOnce("orbis-server/ai/AIChatService.cjs", chatStepOld, chatStepNew);

replaceOnce(
  "orbis-server/ai/AIChatService.cjs",
  `        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);

        if (!brainRequestGateway) {`,
  `        const lang = capabilityIntentMatcher.detectLanguage(lastUserMessage);

        if (capabilityRequest.needsInput) {
          return {
            message: {
              role: "assistant",
              content:
                lang === "bn"
                  ? "কোন allow-listed ফাইলটি পড়ব বলুন: package.json অথবা README.md।"
                  : "Which allow-listed file should I read: package.json or README.md?",
            },
            provider: { name: "ORBIS Brain", type: "BRAIN_CAPABILITY" },
          };
        }

        if (!brainRequestGateway) {`,
);

replaceOnce(
  "orbis-server/ai/AIChatService.cjs",
  `          input: {},
`,
  `          input: capabilityRequest.input || {},
`,
);

replaceOnce(
  "orbis-server/ai/AIChatService.cjs",
  `  if (error.includes("REQUIRE_APPROVAL")) {
    return bn
      ? "এই অনুরোধের জন্য অনুমোদন প্রয়োজন, তাই এটি এখনই কার্যকর করা হয়নি।"
      : "This request requires approval, so it was not executed yet.";
  }`,
  `  if (error.includes("REQUIRE_APPROVAL")) {
    const token = result && result.approvalToken;
    if (token) {
      return bn
        ? \`এই অনুরোধের জন্য আপনার অনুমোদন প্রয়োজন।\\\\n\\\\nApproval token: \${token}\\\\n\\\\nঅনুমোদন করতে লিখুন: APPROVE \${token}\`
        : \`This request requires your approval.\\\\n\\\\nApproval token: \${token}\\\\n\\\\nTo approve this exact request, reply: APPROVE \${token}\`;
    }
    return bn
      ? "এই অনুরোধের জন্য অনুমোদন প্রয়োজন, তাই এটি এখনই কার্যকর করা হয়নি।"
      : "This request requires approval, so it was not executed yet.";
  }`,
);

replaceOnce(
  "orbis-server/ai/AIChatService.cjs",
  "class AIChatService {",
  `function formatApprovalResultAsChatReply(result, lang) {
  const bn = lang === "bn";
  const error = result?.error || "";

  if (result?.success) {
    const capabilityId = result?.metadata?.capabilityId || "termux.file.read";
    return formatBrainResultAsChatReply(capabilityId, result, lang);
  }

  if (error.includes("APPROVAL_REJECTED")) {
    return bn
      ? "অনুরোধটি বাতিল করা হয়েছে এবং কার্যকর করা হয়নি।"
      : "The request was rejected and was not executed.";
  }

  if (error.includes("APPROVAL_EXPIRED")) {
    return bn
      ? "অনুমোদনের সময় শেষ হয়ে গেছে। নতুন করে অনুরোধ করুন।"
      : "The approval expired. Please make the request again.";
  }

  if (error.includes("APPROVAL_REPLAY")) {
    return bn
      ? "এই approval token ইতিমধ্যে ব্যবহার করা হয়েছে।"
      : "This approval token has already been used.";
  }

  if (error.includes("APPROVAL_INVALID")) {
    return bn
      ? "Approval tokenটি বৈধ নয়।"
      : "That approval token is not valid.";
  }

  return bn
    ? \`অনুমোদন সম্পন্ন হয়নি: \${error || "UNKNOWN_ERROR"}\`
    : \`The approval flow did not complete: \${error || "UNKNOWN_ERROR"}\`;
}

class AIChatService {`,
);

const testFiles = [
  "src/core/execution/__tests__/PendingApprovalStore.task019.test.ts",
  "src/core/execution/__tests__/SecureExecutionAuthorizationGate.task019.test.ts",
  "src/core/execution/__tests__/TermuxRuntime.task019.test.ts",
  "orbis-server/__tests__/ChatCapabilityIntentMatcher.task019.test.mjs",
];

// Dry-run mode validates every audited replacement without changing the repository.
if (process.argv.includes("--dry-run")) {
  console.log("TASK-019 dry-run passed. No files were modified.");
  console.log(`Validated ${targets.length} source files and ${testFiles.length} test files.`);
  process.exit(0);
}

// Write everything only after every replacement succeeds.
const backupManifest = [];
for (const file of targets) {
  const backupPath = `${A(file)}.task019-backup-${now}`;
  fs.copyFileSync(A(file), backupPath);
  backupManifest.push({ file, backupPath });
}

const storeSource = fs.readFileSync(
  A(`${PKG}/src/core/execution/authorization/PendingApprovalStore.ts`),
  "utf8",
);

fs.writeFileSync(
  A("src/core/execution/authorization/PendingApprovalStore.ts"),
  storeSource,
  "utf8",
);

for (const file of testFiles) {
  const destination = A(file);
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.copyFileSync(A(`${PKG}/${file}`), destination);
}

for (const [file, content] of staged) {
  fs.writeFileSync(A(file), content, "utf8");
}

const manifestPath = A("TASK-019-secure-approval-flow/.task019-manifest.json");
fs.writeFileSync(
  manifestPath,
  JSON.stringify(
    {
      task: "TASK-019",
      appliedAt: new Date().toISOString(),
      backups: backupManifest,
      createdFiles: [
        "src/core/execution/authorization/PendingApprovalStore.ts",
        ...testFiles,
      ],
    },
    null,
    2,
  ),
  "utf8",
);

console.log("TASK-019 source changes applied locally.");
console.log("No git operations were performed.");
console.log("Backups created with timestamp:", now);
console.log("Next validation:");
console.log("  node --check orbis-server/ai/AIChatService.cjs");
console.log("  node --check orbis-server/ai/brain/ChatCapabilityIntentMatcher.cjs");
console.log("  npm run build");
console.log("  npm test");
console.log("  npm run lint");
console.log("  npm run check:circular");
