import { describe, expect, it } from "vitest";

const matcher = await import("../ai/brain/ChatCapabilityIntentMatcher.cjs");

describe("TASK-019 chat approval and file input matching", () => {
  it("maps explicit allow-listed file requests to deterministic inputs", () => {
    expect(matcher.matchRequest("read package.json")).toEqual({
      capabilityId: "termux.file.read",
      input: { path: "package.json" },
      needsInput: false,
    });

    expect(matcher.matchRequest("README.md দেখাও")).toEqual({
      capabilityId: "termux.file.read",
      input: { path: "README.md" },
      needsInput: false,
    });
  });

  it("never treats a bare yes as approval", () => {
    expect(matcher.matchApprovalDecision("হ্যাঁ")).toBeNull();
    expect(matcher.matchApprovalDecision("yes")).toBeNull();
  });

  it("recognizes approval only when a token is explicitly present", () => {
    const token = "A".repeat(32);
    expect(matcher.matchApprovalDecision(`APPROVE ${token}`)).toEqual({
      token,
      decision: "APPROVE",
    });
    expect(matcher.matchApprovalDecision(`REJECT ${token}`)).toEqual({
      token,
      decision: "REJECT",
    });
  });
});
